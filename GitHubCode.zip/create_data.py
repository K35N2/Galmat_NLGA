# Code to extract Subject,Predicate,Object triples and their corresponding lexicalisation from WebNLG dataset and reformat into sets of questions and answers
# Author: Chiranjeev Keshav Nathoo
# Date: 11th July 2023

import json

# Opening JSON file
fjson = open('valid.json')
  
# returns JSON object as 
# a dictionary
data = json.load(fjson)
fjson.close()

# Opening text file to store training data
file = open("training.txt", 'a')

for entry in data["entries"]:
    for id, graph_data in entry.items():
        # Extract the triples for the current subject
        triples = graph_data.get("modifiedtripleset", [])
        lex = graph_data.get("lexicalisations", [])[0]
        answer = "[A] " + lex["lex"]
        
        # Iterate over the triples and add nodes and edges to the knowledge graph
        question = "[Q] How to describe "
        for triple in triples:
            property_name = triple["property"]
            object_name = triple["object"]
            subject = triple["subject"]
            question += f"({subject}, {property_name}, {object_name}) "
        question += "?"

        file.write(question + '\n')
        file.write(answer + '\n')
file.close()